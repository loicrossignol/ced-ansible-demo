#!/bin/bash

# Functions to write logs
f_log_debug() {
    if test ${LOG_LEVEL} -ge 4; then
        echo -e "$(date +%Y%m%d%H%M%S) - \033[34mDEBUG\033[m -" "$@"
    fi
}
f_log_info() {
    if test ${LOG_LEVEL} -ge 3; then
        echo -e "$(date +%Y%m%d%H%M%S) - \033[32mINFO\033[m -" "$@"
    fi
}
f_log_warning() {
    if test ${LOG_LEVEL} -ge 2; then
        echo -e "$(date +%Y%m%d%H%M%S) - \033[33mWARNING\033[m -" "$@"
    fi
}
f_log_fatal() {
    echo -e "$(date +%Y%m%d%H%M%S) - \033[31mFATAL\033[m -" "$@"
}

# Method to change auth mode in redmine
change_auth_mode_in_redmine()
{
    if test $# != 3; then
        f_log_fatal "ERROR: change_auth_mode_in_redmine invalid arguments ('USAGE: change_auth_mode_in_redmine <user name> <Redmine url> <Redmine token>')"
        exit 1
    fi
    redmineUserToChangeAuthMode="$1" #Name of user to change his auth mode in Redmine
    urlRedmine="$2" #URL of redmine
    redmineToken="$3" #Token used to execute command on Redmine API

    #  Get Redmine user id from username
    USER_ID=$(curl --silent -H "X-Redmine-API-Key: ${redmineToken}" -H "Accept: application/json" -H "Content-Type: application/json" -X GET "${urlRedmine}/users.json?name=${redmineUserToChangeAuthMode}" |  jq -r  '.users[0].id' );
    
    if test ! -z "${USER_ID}" && test "${USER_ID}" != "[]" && test "${USER_ID}" != "null"; then
        if test "${DRY_RUN}" == false; then
            # Put auth mode to internal mode
            curl --silent -H "X-Redmine-API-Key: ${redmineToken}" -H "Accept: application/json" -H "Content-Type: application/json" -X PUT "${urlRedmine}/users/$USER_ID.json" -d '{"user": {"auth_source_id": 0}}';

            if test "$?" -eq 0; then
                f_log_info "Redmine ${urlRedmine}: User '${redmineUserToChangeAuthMode}' (id $USER_ID) uses internal auth mode now."
            else
                f_log_fatal "Error while auth mode changing '${redmineUserToChangeAuthMode}'  in Redmine ${urlRedmine}"
            fi
        else
            # Dry run mode enabled
            f_log_info "** Dry run mode **: Redmine ${urlRedmine}: User '${redmineUserToChangeAuthMode}' (id $USER_ID) uses internal auth mode now." 
        fi
    else
        f_log_warning "User with name '${redmineUserToChangeAuthMode}' doesn't exist in Redmine ${urlRedmine}"
    fi
}
print_help() {
    f_log_info "Usage: change_redmine_auth_mode.sh [OPTIONS] <parameters file>"
    f_log_info "      -p,--parameters-file  (Required)    The path to the parameters file"
    f_log_info "      -l,--log-level                      The log level to use (default is 3)"
    f_log_info "      -d,--dry-run                        Execute script in dry run mode"
    f_log_info "      -h,--help                           Print this help and exit"
    f_log_info
    f_log_info "Examples:" 
    f_log_info "      ./change_redmine_auth_mode.sh -p parameters.txt"
}

#############################################################################################################################################
##### Main process #####
#Initialize variables
DRY_RUN=false
PARAMETER_FILE=""
LOG_LEVEL=3

# check script parameters
OPTS=`getopt -o h,d,l:,p: --long help,dry-run,log-level:parameters-file:  -n 'parse-options' -- "$@"`

if test $? != 0 ; then
    f_log_fatal "Error, no arguments are specified. For more information, print help with --help"
    exit 1
fi

eval set -- "$OPTS"

# Read options
while true; do
  case "$1" in
    -d | --dry-run ) DRY_RUN=true; shift ;;
    -h | --help ) print_help; exit 1 ;;
    -l | --log-level ) LOG_LEVEL="$2"; shift; shift ;;
    -p | --parameters-file ) PARAMETER_FILE="$2"; shift; shift ;;
    * ) break ;;
  esac
done

# Check if parameters needed are given
if test "${PARAMETER_FILE}" == ""; then
    f_log_fatal "File parameter is missing, check arguments required with --help"
    exit 1
fi

if ! test -e "${PARAMETER_FILE}"; then
    f_log_fatal "File parameter "${PARAMETER_FILE}" does not exist"
    exit 1
fi

numericRe='^[0-9]+$'
if ! [[ "${LOG_LEVEL}" =~ ${numericRe} ]]; then
    f_log_fatal "Log level '${LOG_LEVEL}' is not a valid number"
    exit 1
fi

if test "${DRY_RUN}" == true; then
    f_log_warning "*** DRY RUN MODE ENABLED ***"
fi

i=1

while IFS= read  -a  input 
do 
    # Read the line of parameters file and parse with delimiter ' '
    # Be aware to end with a newline in your parameters file
    inputs=($(printf "%s" "$input" | cut -d ' ' -f1-))
    #Wating for 3 parameters
    if [ "${#inputs[@]}" -eq  "3" ]; then
        ## For debug
        #printf "%s\n" "${inputs[0]}" "${inputs[1]}" "${inputs[2]}"
        P_fichier=${inputs[0]} # User file
        P_urlRedmine=${inputs[1]} # URL of each Redmine 
        P_redmine_api_token=${inputs[2]} #Redmine API tokens used to execute commands on Redmine API

        # Get all users email in Redmine
        list_email=$(curl --silent -H "X-Redmine-API-Key: ${P_redmine_api_token}" -H "Accept: application/json" -H "Content-Type: application/json" -X GET "${P_urlRedmine}/users.json" | jq -r '.users[].mail' );
        echo "$list_email" > users.txt
        
        echo ""
        f_log_info "====================== START CHANGING AUTH MODE IN REDMINE ${P_urlRedmine}  ======================"

        while read line 
        do

            # Step: read the file with list of users to change auth mode
            # Parse line by line to retrieve login prenom.nom
            # example : echo "Blanca DALFO FERRER <blanca.dalfo-ferrer@thales-services.fr>" | awk -F"<" '{print $2}' | awk -F"@" '{print $1}' ==> blanca.dalfo-ferrer
            
            username=$(echo $line | awk -F"@" '{print $1}')

            # Change user auth mode in Redmine
            change_auth_mode_in_redmine "${username}" "${P_urlRedmine}" "${P_redmine_api_token}"

        done < "${P_fichier}"
        f_log_info "====================== END CHANGING AUTH MODE IN REDMINE ${P_urlRedmine}  ======================"
        echo ""
    else
        f_log_fatal "==================================== CHANGE AUTH MODE ============================================================"
        f_log_fatal "Need 3 parameters in this order: " 
        f_log_fatal "Users file, URL of Redmine , Redmine API token. "
        f_log_fatal "Mandatory parameters:  users_file.txt https://redmine-collab-so.thales-services.fr  XXXXXXXXXX"
        f_log_fatal "==========================================================================================================================="
        f_log_fatal "ERROR on line number : $i with input $input"
    fi
    ((i++))
done < "${PARAMETER_FILE}"
