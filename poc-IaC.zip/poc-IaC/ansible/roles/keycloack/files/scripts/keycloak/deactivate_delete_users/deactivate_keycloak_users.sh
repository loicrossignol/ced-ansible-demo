#!/bin/bash

# Functions to write logs
f_log_debug() {
    if test ${LOG_LEVEL} -ge 4; then
        echo -e "$(date +%Y%m%d%H%M%S) - \033[34mDEBUG\033[m -" "$@"
    fi
}
f_log_info() {
    if test ${LOG_LEVEL} -ge 3; then
        echo -e "$(date +%Y%m%d%H%M%S) - \033[32mINFO\033[m -" "$@"
    fi
}
f_log_warning() {
    if test ${LOG_LEVEL} -ge 2; then
        echo -e "$(date +%Y%m%d%H%M%S) - \033[33mWARNING\033[m -" "$@"
    fi
}
f_log_fatal() {
    echo -e "$(date +%Y%m%d%H%M%S) - \033[31mFATAL\033[m -" "$@"
}

#  Method to deactivate or delete users from Keycloak
deactivate_user_in_keycloak()
{
    if test $# != 3; then
        f_log_fatal "ERROR: deactivate_user_in_keycloak invalid arguments ('USAGE: deactivate_user_in_keycloak <user name>  <PIC url> <Keycloak token>')"
        exit 1
    fi
    username="$1"
    picUrl="$2"
    keycloakToken="$3"
    KEYCLOAK_REALM=CED 

    USER_ID=$(curl --silent -H "Accept: application/json" -H "Authorization: Bearer ${keycloakToken}"  -X GET "$picUrl/auth/admin/realms/$KEYCLOAK_REALM/users?username=${username}" | jq -r '.[] | .id');

    if test ! -z "${USER_ID}" && test "${USER_ID}" != "[]"; then
        if test "${DRY_RUN}" == false; then
            # Update user from enabled to disabled (A disable user cannot login)
            # curl --silent --output /dev/null --show-error --fail -H "Accept: application/json" -H "Authorization: Bearer ${keycloakToken}"  -H "Content-Type: application/json" -X PUT "$picUrl/auth/admin/realms/$KEYCLOAK_REALM/users/$USER_ID" -d "{\"enabled\" : \"false\"}"
            # STATE=$(curl  --silent -H "Accept: application/json" -H "Authorization: Bearer ${keycloakToken}"  -X GET "$picUrl/auth/admin/realms/$KEYCLOAK_REALM/users?username=${username}" | jq '.[] | .enabled')
            # f_log_debug "STATE has been updated to : '${STATE}'"

            # Delete  user
            curl  -H "Accept: application/json" -H "Authorization: Bearer $TKN"  -X DELETE $P_url/auth/admin/realms/$KEYCLOAK_REALM/users/$USER_ID 
            
            if test "$?" -eq 0; then
                f_log_info "Keycloak: Deactivate $username (id $USER_ID) in $picUrl/auth/"
            else
                f_log_fatal "Error while deactivating '${$username}' in $picUrl/auth/"
            fi

        else
            # Dry run mode enabled
            f_log_info "** Dry run mode **: Keycloak : Deactivate $username (id $USER_ID) in $picUrl/auth/"  
        fi
    else
        f_log_warning "User $username  not in Keycloak or Not active user."
    fi
}

#############################################################################################################################################
##### Main process #####
#Initialize variables
DRY_RUN=false
PARAMETER_FILE=""
LOG_LEVEL=3

# check script parameters
OPTS=`getopt -o h,d,l:,p: --long help,dry-run,log-level:parameters-file:  -n 'parse-options' -- "$@"`

if test $? != 0 ; then
    f_log_fatal "Error, no arguments are specified. For more information, print help with --help"
    exit 1
fi

eval set -- "$OPTS"

# Read options
while true; do
  case "$1" in
    -d | --dry-run ) DRY_RUN=true; shift ;;
    -h | --help ) print_help; exit 1 ;;
    -l | --log-level ) LOG_LEVEL="$2"; shift; shift ;;
    -p | --parameters-file ) PARAMETER_FILE="$2"; shift; shift ;;
    * ) break ;;
  esac
done

# Check if parameters needed are given
if test "${PARAMETER_FILE}" == ""; then
    f_log_fatal "File parameter is missing, check arguments required with --help"
    exit 1
fi

if ! test -e "${PARAMETER_FILE}"; then
    f_log_fatal "File parameter "${PARAMETER_FILE}" does not exist"
    exit 1
fi

numericRe='^[0-9]+$'
if ! [[ "${LOG_LEVEL}" =~ ${numericRe} ]]; then
    f_log_fatal "Log level '${LOG_LEVEL}' is not a valid number"
    exit 1
fi

if test "${DRY_RUN}" == true; then
    f_log_warning "*** DRY RUN MODE ENABLED ***"
fi


i=1
while IFS= read -r  -a  input 
do 
    # Read the line of parameters file and parse with delimiter ' '
    # Be aware to end with a newline in your parameters file
    inputs=($(printf "%s" "$input" | cut -d ' ' -f1-))
    #Wating for 7 parameters
    if [ "${#inputs[@]}" -eq  "7" ]; then
        ## For debug
        #printf "%s" "${inputs[0]}" "${inputs[1]}" "${inputs[2]}" "${inputs[3]}" "${inputs[4]}" "${inputs[5]}" "${inputs[6]}"
        P_fichier=${inputs[0]} #Fichier utilisateurs
        echo "${P_fichier}"
        P_url=${inputs[1]} # URL de chaque PIC 
        P_sonarqube_token=${inputs[2]} #token API Sonarqube
        P_nexus_user=${inputs[3]} #Utilisateur Nexus pour lancer la commande de désactivation de l'utilisateur dans Nexus
        P_nexus_password=${inputs[4]} #User password Nexus
        P_gitlab_token=${inputs[5]} #token API Gitlab
        P_keycloak_password=${inputs[6]} #Admin Keycloak password

        # Keycloak get user emails
        # Config keycloak
        KEYCLOAK_REALM=CED
        TKN=$(curl --silent -X POST "$P_url/auth/realms/master/protocol/openid-connect/token" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        -d "username=admin" \
        -d "password=$P_keycloak_password" \
        -d 'grant_type=password' \
        -d 'client_id=admin-cli' | jq -r '.access_token')

        list_email=$(curl --silent -H "Accept: application/json" -H "Authorization: Bearer ${TKN}"  -X GET "$P_url/auth/admin/realms/$KEYCLOAK_REALM/users?max=10000" | jq -r '.[] | .email');
        echo "$list_email" > users.txt

        ## Ces étapes sont juste là au cas où on n'a plus de SSO ou de LDAP car une fois que l'user est enlevé du SSO/LDAP, 
        ## on ne les a plus dans ces services donc on aura plutot une erreur que les "users ne sont plus là"
        # File list with IDs/logins
        f_log_info "====================== START OF DEACTIVATION OF USER IN PIC ${P_url}  ======================"

        while read line             
        do 
            # Step: read the file with list of users to deactivate
            # Parse line by line to retrieve login: prenom.nom
            # example : echo "Blanca DALFO FERRER <blanca.dalfo-ferrer@thales-services.fr>" | awk -F"<" '{print $2}' | awk -F"@" '{print $1}' ==> blanca.dalfo-ferrer
            userName=$(echo "$line" | awk -F"@" '{print $1}')

            # Keycloak deactivation
            # Config keycloak
            TKN=$(curl --silent -X POST "$P_url/auth/realms/master/protocol/openid-connect/token" \
            -H "Content-Type: application/x-www-form-urlencoded" \
            -d "username=admin" \
            -d "password=$P_keycloak_password" \
            -d 'grant_type=password' \
            -d 'client_id=admin-cli' | jq -r '.access_token')
            deactivate_user_in_keycloak "${userName}" "${P_url}" "${TKN}"

        done < "${P_fichier}"
        f_log_info "====================== END OF USER DEACTIVATION IN PIC ${P_url}  ======================"
        echo ""
    else
        f_log_fatal "====================================DEACTIVATE USERS ACCOUNT ============================================================="
        f_log_fatal "Need 5 parameters in this order: " 
        f_log_fatal "Users file, URL of PIC , Sonarqube token API, Nexus user login,  Nexus user password , Gitlab token and Keycloak admin password. "
        f_log_fatal "Mandatory parameters:  users_file.txt https://usine-collab-so.thales-services.fr <token_sonarqube>  <nexus_username> <nexus_password> <token_gitlab> <admin_keycloak_password>"
        f_log_fatal "==========================================================================================================================="
        f_log_fatal "ERROR on line number : $i with input $input"
    fi
    ((i++))
done < "${PARAMETER_FILE}"
